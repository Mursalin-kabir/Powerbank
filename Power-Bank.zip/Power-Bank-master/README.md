# Building DIY Portable Power Bank

This is a college project.

Main Goal : A Portable Power Bank Input: 3.5V Output: 5V Maximum Output Current: 1A

# Project is managed with NI Multisim
